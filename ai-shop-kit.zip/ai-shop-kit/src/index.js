const COOKIE_NAME = "ask_admin_session";
const SESSION_SECONDS = 60 * 60 * 8;
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
  });
}
function htmlError(message, status = 400) {
  return new Response(message, { status, headers: { "content-type": "text/plain; charset=utf-8" } });
}
function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}
function b64url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromB64url(value) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  const binary = atob(base64);
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}
async function hmac(secret, data) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data)));
}
async function makeSession(env) {
  const payload = b64url(new TextEncoder().encode(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + SESSION_SECONDS })));
  const signature = b64url(await hmac(env.SESSION_SECRET, payload));
  return `${payload}.${signature}`;
}
async function validSession(request, env) {
  const cookie = request.headers.get("Cookie") || "";
  const entry = cookie.split(";").map(x => x.trim()).find(x => x.startsWith(COOKIE_NAME + "="));
  if (!entry || !env.SESSION_SECRET) return false;
  const token = entry.slice(COOKIE_NAME.length + 1);
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  let expected;
  try { expected = b64url(await hmac(env.SESSION_SECRET, parts[0])); } catch { return false; }
  if (!safeEqual(expected, parts[1])) return false;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
    return Number.isInteger(payload.exp) && payload.exp > Math.floor(Date.now() / 1000);
  } catch { return false; }
}
function cookieHeader(value, maxAge = SESSION_SECONDS) {
  return `${COOKIE_NAME}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
function slugify(value) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 70);
}
function cleanProduct(row) {
  return {
    id: row.id, slug: row.slug, name: row.name, price: row.price,
    category: row.category, description: row.description,
    hasFile: Boolean(row.file_key), fileName: row.file_name || null,
    active: Boolean(row.active), createdAt: row.created_at, updatedAt: row.updated_at
  };
}
async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}
async function requireAdmin(request, env) {
  return await validSession(request, env);
}
async function route(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method.toUpperCase();

  if (!env.DB || !env.PRODUCT_FILES) return json({ error: "Thiếu binding DB hoặc PRODUCT_FILES. Xem README.md." }, 500);

  if (path === "/api/health" && method === "GET") {
    return json({ ok: true, app: "AI Shop Kit" });
  }

  if (path === "/api/admin/login" && method === "POST") {
    if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({ error: "Chưa cấu hình ADMIN_PASSWORD hoặc SESSION_SECRET trong Worker Secrets." }, 500);
    const body = await readJson(request);
    if (!body || typeof body.password !== "string" || !safeEqual(body.password, env.ADMIN_PASSWORD)) {
      return json({ error: "Mật khẩu chưa đúng." }, 401);
    }
    const token = await makeSession(env);
    return json({ ok: true }, 200, { "set-cookie": cookieHeader(token) });
  }

  if (path === "/api/admin/logout" && method === "POST") {
    return json({ ok: true }, 200, { "set-cookie": cookieHeader("", 0) });
  }

  if (path === "/api/admin/me" && method === "GET") {
    return json({ authenticated: await validSession(request, env) });
  }

  if (path === "/api/products" && method === "GET") {
    const { results } = await env.DB.prepare(
      "SELECT id, slug, name, price, category, description, file_key, file_name, active, created_at, updated_at FROM products WHERE active = 1 ORDER BY created_at DESC"
    ).all();
    return json({ products: (results || []).map(cleanProduct) }, 200, { "cache-control": "public, max-age=30" });
  }

  if (path.startsWith("/api/admin/")) {
    if (!(await requireAdmin(request, env))) return json({ error: "Bạn cần đăng nhập admin." }, 401);

    if (path === "/api/admin/products" && method === "GET") {
      const { results } = await env.DB.prepare(
        "SELECT id, slug, name, price, category, description, file_key, file_name, active, created_at, updated_at FROM products ORDER BY created_at DESC"
      ).all();
      return json({ products: (results || []).map(cleanProduct) });
    }

    if (path === "/api/admin/products" && method === "POST") {
      const body = await readJson(request);
      if (!body) return json({ error: "JSON không hợp lệ." }, 400);
      const name = String(body.name || "").trim().slice(0, 160);
      const category = String(body.category || "").trim().slice(0, 80);
      const description = String(body.description || "").trim().slice(0, 3000);
      const price = Number(body.price);
      const slug = slugify(String(body.slug || name));
      if (!name || !category || !description || !slug || !Number.isSafeInteger(price) || price < 0) {
        return json({ error: "Vui lòng nhập tên, slug, danh mục, mô tả và giá hợp lệ (giá là số nguyên VNĐ)." }, 400);
      }
      try {
        const result = await env.DB.prepare(
          "INSERT INTO products (slug, name, price, category, description, active) VALUES (?, ?, ?, ?, ?, ?)"
        ).bind(slug, name, price, category, description, body.active ? 1 : 0).run();
        return json({ ok: true, id: result.meta.last_row_id });
      } catch (error) {
        return json({ error: "Không tạo được sản phẩm. Slug có thể đã tồn tại." }, 409);
      }
    }

    const productMatch = path.match(/^\/api\/admin\/products\/(\d+)$/);
    if (productMatch && method === "PUT") {
      const id = Number(productMatch[1]);
      const body = await readJson(request);
      if (!body) return json({ error: "JSON không hợp lệ." }, 400);
      const name = String(body.name || "").trim().slice(0, 160);
      const category = String(body.category || "").trim().slice(0, 80);
      const description = String(body.description || "").trim().slice(0, 3000);
      const price = Number(body.price);
      const slug = slugify(String(body.slug || name));
      if (!name || !category || !description || !slug || !Number.isSafeInteger(price) || price < 0) {
        return json({ error: "Vui lòng nhập đủ trường và giá hợp lệ." }, 400);
      }
      try {
        const result = await env.DB.prepare(
          "UPDATE products SET slug = ?, name = ?, price = ?, category = ?, description = ?, active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
        ).bind(slug, name, price, category, description, body.active ? 1 : 0, id).run();
        if (!result.meta.changes) return json({ error: "Không tìm thấy sản phẩm." }, 404);
        return json({ ok: true });
      } catch {
        return json({ error: "Không cập nhật được. Slug có thể đã được sản phẩm khác sử dụng." }, 409);
      }
    }

    const uploadMatch = path.match(/^\/api\/admin\/products\/(\d+)\/file$/);
    if (uploadMatch && method === "POST") {
      const id = Number(uploadMatch[1]);
      const product = await env.DB.prepare("SELECT id FROM products WHERE id = ?").bind(id).first();
      if (!product) return json({ error: "Không tìm thấy sản phẩm." }, 404);
      const form = await request.formData();
      const file = form.get("file");
      if (!(file instanceof File)) return json({ error: "Chưa chọn file." }, 400);
      if (file.size < 1 || file.size > MAX_UPLOAD_BYTES) return json({ error: "File phải nhỏ hơn 25 MB." }, 413);
      const originalName = file.name.replace(/[^\w.\- ()]/g, "_").slice(0, 120) || "product.zip";
      const key = `products/${id}/${crypto.randomUUID()}-${originalName}`;
      await env.PRODUCT_FILES.put(key, file.stream(), {
        httpMetadata: { contentType: "application/octet-stream", contentDisposition: `attachment; filename="${originalName.replace(/["\\]/g, "_")}"` },
        customMetadata: { productId: String(id) }
      });
      await env.DB.prepare("UPDATE products SET file_key = ?, file_name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .bind(key, originalName, id).run();
      return json({ ok: true, fileName: originalName });
    }

    const adminDownloadMatch = path.match(/^\/api\/admin\/products\/(\d+)\/download$/);
    if (adminDownloadMatch && method === "GET") {
      const product = await env.DB.prepare("SELECT file_key, file_name FROM products WHERE id = ?").bind(Number(adminDownloadMatch[1])).first();
      if (!product || !product.file_key) return json({ error: "Sản phẩm chưa có file." }, 404);
      const object = await env.PRODUCT_FILES.get(product.file_key);
      if (!object) return json({ error: "Không tìm thấy file trong R2." }, 404);
      const headers = new Headers();
      object.writeHttpMetadata(headers);
      headers.set("content-type", "application/octet-stream");
      headers.set("content-disposition", `attachment; filename="${String(product.file_name || "product.zip").replace(/["\\]/g, "_")}"`);
      headers.set("cache-control", "private, no-store");
      headers.set("x-content-type-options", "nosniff");
      return new Response(object.body, { headers });
    }

    return json({ error: "API admin không tồn tại." }, 404);
  }

  // The static frontend is served by the Workers Assets binding after this function returns undefined.
  return undefined;
}

export default {
  async fetch(request, env) {
    try {
      const response = await route(request, env);
      if (response) return response;
      return env.ASSETS.fetch(request);
    } catch (error) {
      console.error("Request failed", error?.message || error);
      return json({ error: "Có lỗi hệ thống. Vui lòng thử lại." }, 500);
    }
  }
};
