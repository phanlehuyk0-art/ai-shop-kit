# AI Shop Kit — bộ khởi đầu cho Cloudflare

Đây là bản MVP mẫu để quản lý sản phẩm thật bằng Cloudflare Workers + D1 + R2:
- Cửa hàng công khai chỉ hiển thị sản phẩm `active = 1`.
- Admin đăng nhập bằng Worker Secret `ADMIN_PASSWORD`.
- Cookie phiên admin được ký HMAC, `HttpOnly`, `Secure`, `SameSite=Strict`, hết hạn sau 8 giờ.
- Admin thêm/sửa sản phẩm, đặt giá, bật/tắt hiển thị và tải file lên bucket R2 riêng tư.
- File sản phẩm không có URL công khai; admin có thể tải thử sau khi đăng nhập.

## Chưa có trong bản này
- Chưa tích hợp thanh toán.
- Chưa có giao file tự động cho khách đã mua. API tải file hiện chỉ dành cho admin để kiểm tra upload.
- Chưa có quên mật khẩu, nhiều tài khoản admin, CAPTCHA hay hệ thống email.
- Đây là starter cần được kiểm thử trước khi dùng cho hoạt động kinh doanh thực tế.

## Bạn cần
- Tài khoản Cloudflare.
- Máy tính được khuyến nghị để chạy Node.js và Wrangler. Có thể thao tác một phần trên điện thoại nhưng sẽ khó hơn.
- Node.js phiên bản LTS hiện hành.

## A. Tạo tài nguyên trên Cloudflare
1. Trong Cloudflare Dashboard, tạo D1 database tên `ai-shop-kit-db`.
2. Mở SQL Console của database và chạy toàn bộ nội dung `schema.sql`.
3. Vào Workers & Pages, tạo Worker tên `ai-shop-kit`.
4. Tạo R2 bucket tên `ai-shop-kit-files`, để private (không bật public access).
5. Mở phần Settings/Bindings của Worker:
   - D1 binding: variable name `DB`, chọn `ai-shop-kit-db`.
   - R2 binding: variable name `PRODUCT_FILES`, chọn `ai-shop-kit-files`.
6. Mở database D1, sao chép Database ID và thay `PASTE_YOUR_D1_DATABASE_ID_HERE` trong `wrangler.jsonc`.
   Nếu bạn dùng Wrangler để tạo database mới, hãy cập nhật `database_id` theo kết quả CLI.

## B. Cấu hình secrets
Trong thư mục dự án, mở Terminal và chạy:
```bash
npm install
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put SESSION_SECRET
```
- Nhập một mật khẩu admin dài, độc nhất.
- Với `SESSION_SECRET`, nhập chuỗi ngẫu nhiên dài tối thiểu 32 ký tự.
- Không ghi các secret vào `src/index.js`, HTML, GitHub hay ảnh chụp màn hình.
- Khi chạy local, có thể tạo `.dev.vars` (đừng commit file này):
```dotenv
ADMIN_PASSWORD="dung-mat-khau-rieng-cua-ban"
SESSION_SECRET="chuoi-ngau-nhien-dai-it-nhat-32-ky-tu"
```

## C. Chạy local
```bash
npm run dev
```
Mở địa chỉ localhost do Wrangler hiển thị. Local dev cần cấu hình D1/R2 local/remote đúng theo hướng dẫn Wrangler; nếu không, dùng binding remote có chủ ý và cẩn thận dữ liệu.

## D. Triển khai
```bash
npm run deploy
```
Sau khi deploy, mở URL Worker được cung cấp. Thử `/api/health`, rồi `/admin.html`.

## E. Thêm sản phẩm
1. Mở `/admin.html`.
2. Đăng nhập bằng `ADMIN_PASSWORD`.
3. Nhập tên, slug, giá VNĐ, danh mục, mô tả.
4. Để `Hiển thị công khai` tắt khi đang soạn; bật khi đã kiểm tra nội dung.
5. Bấm `Lưu sản phẩm`.
6. Bấm `Sửa` trên sản phẩm vừa tạo.
7. Chọn file ZIP/PDF và bấm `Tải file lên kho riêng tư`.
8. Dùng nút `Tải thử file` để kiểm tra quyền tải admin.
9. Mở trang chủ để xác nhận sản phẩm hiển thị nếu đã bật công khai.

## Sản phẩm mẫu của bạn
- Tên: Shop Content Kit 30 ngày
- Giá: 79000 VNĐ
- Danh mục: Kịch bản video
- Mô tả: Bộ kịch bản video, prompt AI và lịch nội dung cho shop thời trang.

Bản starter không tự chèn dữ liệu mẫu vào database. Hãy nhập sản phẩm qua admin để xác nhận chức năng CRUD hoạt động.

## Bảo mật trước khi mở bán
- Đảm bảo HTTPS được dùng; cookie phiên yêu cầu Secure.
- Dùng mật khẩu admin độc nhất, không chia sẻ.
- Không bật public access cho bucket R2.
- Kiểm thử login sai, session hết hạn, giá không hợp lệ, slug trùng, file quá lớn, upload không đăng nhập và truy cập download không đăng nhập.
- Không thêm thanh toán thật cho đến khi webhook được xác minh chữ ký, số tiền, mã đơn và chống xử lý lặp.
- Trước khi bán thật, bổ sung giới hạn đăng nhập, giám sát/log an toàn, backup, chính sách bảo mật và quy trình xử lý sự cố.
