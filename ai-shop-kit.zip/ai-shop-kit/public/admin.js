const $ = selector => document.querySelector(selector);
let products = [];
let editingId = null;
const money = value => new Intl.NumberFormat("vi-VN").format(value) + "đ";
function message(selector, text, error = false) {
  const el = $(selector); el.textContent = text; el.classList.toggle("error", error);
}
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Có lỗi xảy ra.");
  return data;
}
function setLoggedIn(value) {
  $("#login-panel").classList.toggle("hidden", value);
  $("#admin-panel").classList.toggle("hidden", !value);
  $("#logout").classList.toggle("hidden", !value);
}
async function checkSession() {
  try { const result = await api("/api/admin/me"); setLoggedIn(result.authenticated); if (result.authenticated) await loadProducts(); }
  catch { setLoggedIn(false); }
}
$("#login-form").addEventListener("submit", async event => {
  event.preventDefault();
  message("#login-message", "Đang đăng nhập…");
  try {
    await api("/api/admin/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ password: $("#admin-password").value }) });
    $("#admin-password").value = "";
    message("#login-message", "");
    setLoggedIn(true);
    await loadProducts();
  } catch (error) { message("#login-message", error.message, true); }
});
$("#logout").addEventListener("click", async () => {
  try { await api("/api/admin/logout", { method: "POST" }); } finally { setLoggedIn(false); }
});
function resetForm() {
  editingId = null; $("#product-form").reset(); $("#product-id").value = "";
  $("#form-title").textContent = "Thêm sản phẩm"; $("#active").checked = false;
  message("#form-message", ""); message("#file-message", "");
}
$("#reset-form").addEventListener("click", resetForm);
$("#name").addEventListener("input", () => {
  if (!editingId) $("#slug").value = $("#name").value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g,"d").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
});
$("#product-form").addEventListener("submit", async event => {
  event.preventDefault();
  const body = {
    name: $("#name").value.trim(), slug: $("#slug").value.trim(),
    price: Number($("#price").value), category: $("#category").value,
    description: $("#description").value.trim(), active: $("#active").checked
  };
  try {
    if (editingId) await api(`/api/admin/products/${editingId}`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    else await api("/api/admin/products", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    message("#form-message", editingId ? "Đã cập nhật sản phẩm." : "Đã tạo sản phẩm.");
    resetForm(); await loadProducts();
  } catch (error) { message("#form-message", error.message, true); }
});
$("#upload-file").addEventListener("click", async () => {
  if (!editingId) { message("#file-message", "Hãy lưu sản phẩm trước, sau đó bấm Sửa để chọn sản phẩm và tải file.", true); return; }
  const file = $("#product-file").files[0];
  if (!file) { message("#file-message", "Hãy chọn file trước.", true); return; }
  const form = new FormData(); form.append("file", file);
  try {
    await api(`/api/admin/products/${editingId}/file`, { method: "POST", body: form });
    message("#file-message", "Đã tải file lên kho riêng tư R2.");
    $("#product-file").value = ""; await loadProducts();
  } catch (error) { message("#file-message", error.message, true); }
});
async function loadProducts() {
  try {
    const data = await api("/api/admin/products"); products = data.products || [];
    const list = $("#products-list"); list.replaceChildren();
    if (!products.length) { list.innerHTML = '<div class="empty">Chưa có sản phẩm. Hãy tạo sản phẩm ở biểu mẫu bên trái.</div>'; return; }
    for (const product of products) {
      const card = document.createElement("article"); card.className = "admin-product";
      const top = document.createElement("div"); top.className = "admin-product-top";
      const left = document.createElement("div");
      const title = document.createElement("h3"); title.textContent = product.name;
      const slug = document.createElement("p"); slug.textContent = "/" + product.slug;
      left.append(title, slug);
      const badge = document.createElement("span"); badge.className = "pill" + (product.active ? "" : " off"); badge.textContent = product.active ? "Đang hiển thị" : "Bản nháp";
      top.append(left, badge);
      const details = document.createElement("p"); details.textContent = `${product.category} · ${money(product.price)}`;
      const file = document.createElement("p"); file.textContent = product.hasFile ? `File: ${product.fileName}` : "Chưa có file sản phẩm";
      const actions = document.createElement("div"); actions.className = "admin-actions";
      const edit = document.createElement("button"); edit.textContent = "Sửa"; edit.addEventListener("click", () => editProduct(product.id));
      actions.append(edit);
      if (product.hasFile) {
        const download = document.createElement("button"); download.textContent = "Tải thử file"; download.addEventListener("click", async () => {
          try {
            const response = await fetch(`/api/admin/products/${product.id}/download`, { credentials: "same-origin" });
            if (!response.ok) { const d = await response.json().catch(()=>({})); throw new Error(d.error || "Không tải được file."); }
            const blob = await response.blob(); const objectUrl = URL.createObjectURL(blob);
            const a = document.createElement("a"); a.href = objectUrl; a.download = product.fileName || "product-file"; a.click();
            setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
          } catch (error) { alert(error.message); }
        });
        actions.append(download);
      }
      card.append(top, details, file, actions); list.append(card);
    }
  } catch (error) { $("#products-list").textContent = error.message; }
}
function editProduct(id) {
  const p = products.find(item => item.id === id); if (!p) return;
  editingId = p.id; $("#product-id").value = p.id; $("#name").value = p.name; $("#slug").value = p.slug;
  $("#price").value = p.price; $("#category").value = p.category; $("#description").value = p.description; $("#active").checked = p.active;
  $("#form-title").textContent = `Sửa sản phẩm #${p.id}`; $("#product-file").value = "";
  message("#form-message", "Đang sửa sản phẩm. Sau khi lưu, có thể tải file lên.");
  message("#file-message", p.hasFile ? `File hiện tại: ${p.fileName}` : "Sản phẩm chưa có file.");
  window.scrollTo({ top: 0, behavior: "smooth" });
}
$("#refresh").addEventListener("click", loadProducts);
checkSession();
