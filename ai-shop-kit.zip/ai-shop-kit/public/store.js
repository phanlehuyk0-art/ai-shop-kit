const money = value => new Intl.NumberFormat("vi-VN").format(value) + "đ";
async function loadProducts() {
  const grid = document.querySelector("#product-grid");
  const count = document.querySelector("#count");
  try {
    const response = await fetch("/api/products");
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Không tải được sản phẩm.");
    const products = data.products || [];
    count.textContent = `${products.length} sản phẩm`;
    if (!products.length) {
      grid.innerHTML = '<div class="empty">Chưa có sản phẩm nào được xuất bản. Admin có thể thêm sản phẩm trong khu vực quản trị.</div>';
      return;
    }
    grid.replaceChildren();
    for (const product of products) {
      const card = document.createElement("article");
      card.className = "product-card";
      const category = document.createElement("div"); category.className = "category"; category.textContent = product.category;
      const title = document.createElement("h3"); title.textContent = product.name;
      const description = document.createElement("p"); description.textContent = product.description;
      const price = document.createElement("div"); price.className = "price"; price.textContent = money(product.price);
      const button = document.createElement("button"); button.className = "secondary-button"; button.textContent = "Sắp mở bán"; button.disabled = true; button.title = "Thanh toán chưa được tích hợp";
      card.append(category, title, description, price, button);
      grid.append(card);
    }
  } catch {
    grid.innerHTML = '<div class="empty">Không tải được sản phẩm. Vui lòng thử lại sau.</div>';
    count.textContent = "";
  }
}
loadProducts();
